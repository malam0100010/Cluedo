package experiment;

import java.util.Set;

public class TestBoard 
{
    private TestBoardCell[][] board;
    private int numRows;
    private int numCols;
    TestBoardCell testBoardCell;
    Set<TestBoardCell> targets;

    TestBoard()
    {

    }

    void calcTargets( TestBoardCell startCell, int pathlength)
    {
        return;
    }

    TestBoardCell getCell(int row, int col)
    {
        return testBoardCell;
    }

    Set<TestBoardCell> getTargets()
    {
        return targets;
    }


}
